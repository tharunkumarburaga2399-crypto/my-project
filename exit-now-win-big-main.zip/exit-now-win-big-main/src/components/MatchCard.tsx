import { useNavigate } from 'react-router-dom';
import type { Match } from '@/lib/mockData';
import { ChevronRight, Star } from 'lucide-react';

const MatchCard = ({ match }: { match: Match }) => {
  const navigate = useNavigate();
  const isLive = match.status === 'live';
  const isUpcoming = match.status === 'upcoming';

  return (
    <button
      onClick={() => navigate(`/match/${match.id}`)}
      className="w-full rounded-lg border border-border bg-card p-4 text-left transition-all hover:border-primary/30 active:scale-[0.98]"
    >
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-medium uppercase text-muted-foreground">
          {match.sport === 'cricket' ? '🏏 Cricket' : '⚽ Football'}
        </span>
        {isLive && (
          <span className="flex items-center gap-1 rounded-full bg-live/20 px-2 py-0.5 text-xs font-bold text-live">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-live" />
            LIVE
          </span>
        )}
        {isUpcoming && (
          <span className="text-xs text-muted-foreground">{match.time}</span>
        )}
        {match.status === 'completed' && (
          <span className="text-xs text-muted-foreground">Completed</span>
        )}
      </div>

      <div className="flex items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-xs font-bold">
              {match.team1Short}
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">{match.team1Short}</p>
              {match.score1 && <p className="text-xs text-primary font-medium">{match.score1}</p>}
            </div>
          </div>
        </div>

        <div className="px-3 text-xs font-bold text-muted-foreground">VS</div>

        <div className="flex-1 text-right">
          <div className="flex items-center justify-end gap-2">
            <div>
              <p className="text-sm font-semibold text-foreground">{match.team2Short}</p>
              {match.score2 && <p className="text-xs text-primary font-medium">{match.score2}</p>}
            </div>
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-xs font-bold">
              {match.team2Short}
            </div>
          </div>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Star className="h-3 w-3 text-primary" />
          {match.pools} Pools
        </div>
        <ChevronRight className="h-4 w-4 text-muted-foreground" />
      </div>
    </button>
  );
};

export default MatchCard;
