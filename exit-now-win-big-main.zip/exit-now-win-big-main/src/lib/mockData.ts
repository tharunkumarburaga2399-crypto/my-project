export interface Player {
  id: string;
  name: string;
  role: 'batsman' | 'bowler' | 'all-rounder' | 'keeper';
  team: string;
  image?: string;
}

export interface Pool {
  id: string;
  matchId: string;
  name: string;
  players: Player[];
  multiplier: number;
  totalBets: number;
  participantCount: number;
}

export interface Match {
  id: string;
  team1: string;
  team1Short: string;
  team2: string;
  team2Short: string;
  sport: 'cricket' | 'football';
  status: 'live' | 'upcoming' | 'completed';
  score1?: string;
  score2?: string;
  time: string;
  startTime: string;
  pools: number;
}

export interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal' | 'pool_entry' | 'winning';
  amount: number;
  description: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
}

export const matches: Match[] = [
  { id: '1', team1: 'Mumbai Indians', team1Short: 'MI', team2: 'Chennai Super Kings', team2Short: 'CSK', sport: 'cricket', status: 'live', score1: '182/4', score2: '145/3 (16.2)', time: 'LIVE', startTime: '2026-04-01T14:00:00', pools: 4 },
  { id: '2', team1: 'Royal Challengers', team1Short: 'RCB', team2: 'Kolkata Knight Riders', team2Short: 'KKR', sport: 'cricket', status: 'live', score1: '95/2', score2: '---', time: 'LIVE', startTime: '2026-04-01T18:00:00', pools: 3 },
  { id: '3', team1: 'Arsenal', team1Short: 'ARS', team2: 'Manchester City', team2Short: 'MCI', sport: 'football', status: 'upcoming', time: 'Today 8:30 PM', startTime: '2026-04-01T20:30:00', pools: 4 },
  { id: '4', team1: 'Delhi Capitals', team1Short: 'DC', team2: 'Rajasthan Royals', team2Short: 'RR', sport: 'cricket', status: 'upcoming', time: 'Tomorrow 3:30 PM', startTime: '2026-04-02T15:30:00', pools: 3 },
  { id: '5', team1: 'Gujarat Titans', team1Short: 'GT', team2: 'Lucknow Giants', team2Short: 'LSG', sport: 'cricket', status: 'completed', score1: '198/5', score2: '176/8', time: 'Completed', startTime: '2026-03-31T14:00:00', pools: 4 },
];

export const pools: Pool[] = [
  // Match 1: MI vs CSK
  {
    id: 'p1', matchId: '1', name: 'Power Hitters',
    players: [
      { id: 'pl1', name: 'Rohit Sharma', role: 'batsman', team: 'MI' },
      { id: 'pl2', name: 'Suryakumar Yadav', role: 'batsman', team: 'MI' },
    ],
    multiplier: 2.5, totalBets: 125000, participantCount: 342,
  },
  {
    id: 'p2', matchId: '1', name: 'Super Kings',
    players: [
      { id: 'pl3', name: 'MS Dhoni', role: 'keeper', team: 'CSK' },
      { id: 'pl4', name: 'Ravindra Jadeja', role: 'all-rounder', team: 'CSK' },
    ],
    multiplier: 1.8, totalBets: 98000, participantCount: 278,
  },
  {
    id: 'p3', matchId: '1', name: 'All-Rounders',
    players: [
      { id: 'pl5', name: 'Hardik Pandya', role: 'all-rounder', team: 'MI' },
      { id: 'pl6', name: 'Deepak Chahar', role: 'bowler', team: 'CSK' },
    ],
    multiplier: 3.2, totalBets: 67000, participantCount: 156,
  },
  {
    id: 'p4', matchId: '1', name: 'Wicket Takers',
    players: [
      { id: 'pl7', name: 'Jasprit Bumrah', role: 'bowler', team: 'MI' },
      { id: 'pl8', name: 'Matheesha Pathirana', role: 'bowler', team: 'CSK' },
    ],
    multiplier: 4.0, totalBets: 45000, participantCount: 98,
  },

  // Match 2: RCB vs KKR
  {
    id: 'p5', matchId: '2', name: 'Run Machines',
    players: [
      { id: 'pl9', name: 'Virat Kohli', role: 'batsman', team: 'RCB' },
      { id: 'pl10', name: 'Faf du Plessis', role: 'batsman', team: 'RCB' },
    ],
    multiplier: 2.0, totalBets: 200000, participantCount: 520,
  },
  {
    id: 'p6', matchId: '2', name: 'Knight Warriors',
    players: [
      { id: 'pl11', name: 'Andre Russell', role: 'all-rounder', team: 'KKR' },
      { id: 'pl12', name: 'Sunil Narine', role: 'all-rounder', team: 'KKR' },
    ],
    multiplier: 2.8, totalBets: 150000, participantCount: 390,
  },
  {
    id: 'p7', matchId: '2', name: 'Impact Players',
    players: [
      { id: 'pl13', name: 'Glenn Maxwell', role: 'all-rounder', team: 'RCB' },
      { id: 'pl14', name: 'Rinku Singh', role: 'batsman', team: 'KKR' },
    ],
    multiplier: 3.5, totalBets: 80000, participantCount: 210,
  },

  // Match 3: ARS vs MCI
  {
    id: 'p8', matchId: '3', name: 'Goal Scorers',
    players: [
      { id: 'pl15', name: 'Bukayo Saka', role: 'batsman', team: 'ARS' },
      { id: 'pl16', name: 'Martin Odegaard', role: 'batsman', team: 'ARS' },
    ],
    multiplier: 2.2, totalBets: 180000, participantCount: 445,
  },
  {
    id: 'p9', matchId: '3', name: 'City Stars',
    players: [
      { id: 'pl17', name: 'Erling Haaland', role: 'batsman', team: 'MCI' },
      { id: 'pl18', name: 'Kevin De Bruyne', role: 'all-rounder', team: 'MCI' },
    ],
    multiplier: 1.9, totalBets: 220000, participantCount: 510,
  },
  {
    id: 'p10', matchId: '3', name: 'Midfield Masters',
    players: [
      { id: 'pl19', name: 'Declan Rice', role: 'all-rounder', team: 'ARS' },
      { id: 'pl20', name: 'Bernardo Silva', role: 'all-rounder', team: 'MCI' },
    ],
    multiplier: 3.0, totalBets: 95000, participantCount: 230,
  },
  {
    id: 'p11', matchId: '3', name: 'Defenders',
    players: [
      { id: 'pl21', name: 'William Saliba', role: 'bowler', team: 'ARS' },
      { id: 'pl22', name: 'Ruben Dias', role: 'bowler', team: 'MCI' },
    ],
    multiplier: 5.0, totalBets: 30000, participantCount: 75,
  },

  // Match 4: DC vs RR
  {
    id: 'p12', matchId: '4', name: 'Top Order',
    players: [
      { id: 'pl23', name: 'David Warner', role: 'batsman', team: 'DC' },
      { id: 'pl24', name: 'Yashasvi Jaiswal', role: 'batsman', team: 'RR' },
    ],
    multiplier: 2.3, totalBets: 110000, participantCount: 300,
  },
  {
    id: 'p13', matchId: '4', name: 'Match Winners',
    players: [
      { id: 'pl25', name: 'Rishabh Pant', role: 'keeper', team: 'DC' },
      { id: 'pl26', name: 'Jos Buttler', role: 'keeper', team: 'RR' },
    ],
    multiplier: 2.0, totalBets: 140000, participantCount: 380,
  },
  {
    id: 'p14', matchId: '4', name: 'Spin Kings',
    players: [
      { id: 'pl27', name: 'Axar Patel', role: 'all-rounder', team: 'DC' },
      { id: 'pl28', name: 'Yuzvendra Chahal', role: 'bowler', team: 'RR' },
    ],
    multiplier: 3.8, totalBets: 55000, participantCount: 130,
  },

  // Match 5: GT vs LSG (completed)
  {
    id: 'p15', matchId: '5', name: 'Star Performers',
    players: [
      { id: 'pl29', name: 'Shubman Gill', role: 'batsman', team: 'GT' },
      { id: 'pl30', name: 'KL Rahul', role: 'batsman', team: 'LSG' },
    ],
    multiplier: 2.1, totalBets: 160000, participantCount: 410,
  },
  {
    id: 'p16', matchId: '5', name: 'Game Changers',
    players: [
      { id: 'pl31', name: 'Rashid Khan', role: 'bowler', team: 'GT' },
      { id: 'pl32', name: 'Marcus Stoinis', role: 'all-rounder', team: 'LSG' },
    ],
    multiplier: 3.0, totalBets: 90000, participantCount: 220,
  },
  {
    id: 'p17', matchId: '5', name: 'Pace Attack',
    players: [
      { id: 'pl33', name: 'Mohammed Shami', role: 'bowler', team: 'GT' },
      { id: 'pl34', name: 'Mark Wood', role: 'bowler', team: 'LSG' },
    ],
    multiplier: 4.5, totalBets: 35000, participantCount: 85,
  },
  {
    id: 'p18', matchId: '5', name: 'Finishers',
    players: [
      { id: 'pl35', name: 'David Miller', role: 'batsman', team: 'GT' },
      { id: 'pl36', name: 'Nicholas Pooran', role: 'keeper', team: 'LSG' },
    ],
    multiplier: 2.7, totalBets: 75000, participantCount: 190,
  },
];

export const transactions: Transaction[] = [
  { id: 't1', type: 'winning', amount: 250, description: 'Pool winning - MI vs CSK', date: '2026-03-31', status: 'completed' },
  { id: 't2', type: 'pool_entry', amount: -100, description: 'Joined Power Hitters pool', date: '2026-04-01', status: 'completed' },
  { id: 't3', type: 'deposit', amount: 500, description: 'Wallet top-up', date: '2026-03-30', status: 'completed' },
  { id: 't4', type: 'withdrawal', amount: -200, description: 'Bank withdrawal', date: '2026-03-29', status: 'pending' },
  { id: 't5', type: 'winning', amount: 1200, description: 'Pool winning - GT vs LSG', date: '2026-03-28', status: 'completed' },
];
