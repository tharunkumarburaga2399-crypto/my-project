import { matches, pools } from '@/lib/mockData';
import { Star, Users, TrendingUp, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const Contests = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen pb-20">
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-xl">
        <div className="mx-auto max-w-lg px-4 py-3">
          <h1 className="text-lg font-bold">Player Pools</h1>
          <p className="text-xs text-muted-foreground">Pick your players, place your bet</p>
        </div>
      </header>

      <div className="mx-auto max-w-lg px-4 py-4 space-y-6">
        {matches.filter(m => m.status !== 'completed').map(match => {
          const matchPools = pools.filter(p => p.matchId === match.id);
          if (matchPools.length === 0) return null;

          return (
            <section key={match.id}>
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Star className="h-4 w-4 text-primary" />
                  <span className="text-sm font-semibold">{match.team1Short} vs {match.team2Short}</span>
                </div>
                {match.status === 'live' && (
                  <span className="flex items-center gap-1 text-xs font-bold text-live">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-live" /> LIVE
                  </span>
                )}
              </div>

              <div className="space-y-3">
                {matchPools.map(pool => (
                  <div key={pool.id} className="rounded-lg border border-border bg-card p-4">
                    <div className="mb-3 flex items-center justify-between">
                      <h4 className="text-sm font-bold">{pool.name}</h4>
                      <div className="flex items-center gap-1 rounded-full bg-primary/20 px-2 py-0.5">
                        <TrendingUp className="h-3 w-3 text-primary" />
                        <span className="text-xs font-bold text-primary">{pool.multiplier}x</span>
                      </div>
                    </div>

                    <div className="mb-3 flex gap-2">
                      {pool.players.map(player => (
                        <div key={player.id} className="flex items-center gap-1.5 rounded-md bg-secondary/50 px-2 py-1">
                          <User className="h-3 w-3 text-muted-foreground" />
                          <span className="text-[11px] font-medium">{player.name}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          {pool.participantCount}
                        </span>
                        <span>₹{(pool.totalBets / 1000).toFixed(0)}K pool</span>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => navigate(`/match/${match.id}`)}
                        className="bg-gold-gradient text-primary-foreground hover:opacity-90 text-xs font-bold"
                      >
                        JOIN POOL
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
};

export default Contests;
