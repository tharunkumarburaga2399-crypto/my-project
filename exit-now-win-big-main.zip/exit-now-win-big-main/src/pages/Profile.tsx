import { useNavigate } from 'react-router-dom';
import { User, Mail, Phone, Trophy, LogOut, ChevronRight, Shield, HelpCircle, FileText } from 'lucide-react';

const Profile = () => {
  const navigate = useNavigate();

  const menuItems = [
    { icon: Trophy, label: 'Game History', desc: 'View past contests' },
    { icon: Shield, label: 'KYC Verification', desc: 'Verify your identity' },
    { icon: HelpCircle, label: 'Help & Support', desc: 'Get assistance' },
    { icon: FileText, label: 'Terms & Conditions', desc: 'Read our policies' },
  ];

  return (
    <div className="min-h-screen pb-20">
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-xl">
        <div className="mx-auto max-w-lg px-4 py-3">
          <h1 className="text-lg font-bold">Profile</h1>
        </div>
      </header>

      <div className="mx-auto max-w-lg px-4 py-4 space-y-6">
        {/* Profile Card */}
        <div className="rounded-xl bg-card p-6 text-center border border-border">
          <div className="mx-auto mb-3 flex h-20 w-20 items-center justify-center rounded-full bg-gold-gradient text-2xl font-bold text-primary-foreground">
            RK
          </div>
          <h2 className="text-lg font-bold">Rahul Kumar</h2>
          <div className="mt-2 flex items-center justify-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> rahul@email.com</span>
            <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> +91 98765</span>
          </div>
          <button className="mt-3 rounded-lg bg-secondary px-4 py-1.5 text-xs font-medium text-secondary-foreground">
            Edit Profile
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-lg bg-surface p-3 text-center">
            <p className="text-lg font-bold text-primary">24</p>
            <p className="text-xs text-muted-foreground">Contests</p>
          </div>
          <div className="rounded-lg bg-surface p-3 text-center">
            <p className="text-lg font-bold text-success">18</p>
            <p className="text-xs text-muted-foreground">Wins</p>
          </div>
          <div className="rounded-lg bg-surface p-3 text-center">
            <p className="text-lg font-bold text-primary">₹3.2K</p>
            <p className="text-xs text-muted-foreground">Earned</p>
          </div>
        </div>

        {/* Menu */}
        <div className="space-y-1">
          {menuItems.map(({ icon: Icon, label, desc }) => (
            <button key={label} className="flex w-full items-center gap-3 rounded-lg p-3 text-left transition-colors hover:bg-surface">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-surface">
                <Icon className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">{label}</p>
                <p className="text-xs text-muted-foreground">{desc}</p>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
          ))}
        </div>

        {/* Logout */}
        <button
          onClick={() => navigate('/login')}
          className="flex w-full items-center justify-center gap-2 rounded-lg border border-destructive/30 p-3 text-sm font-medium text-destructive transition-colors hover:bg-destructive/10"
        >
          <LogOut className="h-4 w-4" /> Logout
        </button>
      </div>
    </div>
  );
};

export default Profile;
