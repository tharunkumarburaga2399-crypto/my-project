import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowLeft } from 'lucide-react';

const ForgotPassword = () => {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6">
      <div className="w-full max-w-sm space-y-8">
        <button onClick={() => navigate('/login')} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to Login
        </button>

        <div>
          <h1 className="text-xl font-bold">Reset Password</h1>
          <p className="mt-1 text-sm text-muted-foreground">Enter your email to receive an OTP</p>
        </div>

        <form onSubmit={(e) => { e.preventDefault(); navigate('/login'); }} className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Email</label>
            <Input type="email" placeholder="Enter your email" className="bg-surface border-border" />
          </div>
          <Button type="submit" className="w-full bg-gold-gradient text-primary-foreground font-bold hover:opacity-90">
            Send OTP
          </Button>
        </form>
      </div>
    </div>
  );
};

export default ForgotPassword;
