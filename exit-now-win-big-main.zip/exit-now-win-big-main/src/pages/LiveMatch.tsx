import { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { matches, pools } from '@/lib/mockData';
import { ArrowLeft, TrendingUp, Clock, Zap, User } from 'lucide-react';

const LiveMatch = () => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const match = matches.find(m => m.id === id);

  const poolId = searchParams.get('pool');
  const betAmountParam = parseInt(searchParams.get('bet') || '49');
  const pool = pools.find(p => p.id === poolId);

  const [estimatedWinning, setEstimatedWinning] = useState(betAmountParam * (pool?.multiplier || 2.5));
  const [hasExited, setHasExited] = useState(false);
  const [exitAmount, setExitAmount] = useState(0);
  const [multiplier, setMultiplier] = useState(pool?.multiplier || 2.5);
  const [seconds, setSeconds] = useState(0);

  // Simulate changing winnings based on bet amount
  useEffect(() => {
    if (hasExited) return;
    const interval = setInterval(() => {
      setSeconds(s => s + 1);
      setMultiplier(prev => {
        const change = (Math.random() - 0.45) * 0.15;
        return Math.max(0.5, parseFloat((prev + change).toFixed(2)));
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [hasExited]);

  // Update estimated winning when multiplier changes
  useEffect(() => {
    if (!hasExited) {
      setEstimatedWinning(Math.round(betAmountParam * multiplier));
    }
  }, [multiplier, betAmountParam, hasExited]);

  const handleExit = () => {
    setHasExited(true);
    setExitAmount(estimatedWinning);
  };

  const profit = hasExited ? exitAmount - betAmountParam : estimatedWinning - betAmountParam;
  const isProfit = profit > 0;

  if (!match) return <div className="p-4 text-center text-muted-foreground">Match not found</div>;

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-lg items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex-1 text-center">
            <p className="text-sm font-semibold">{match.team1Short} vs {match.team2Short}</p>
            {pool && <p className="text-[10px] text-muted-foreground">{pool.name} Pool</p>}
          </div>
          <span className="flex items-center gap-1 rounded-full bg-live/20 px-2 py-0.5 text-xs font-bold text-live">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-live" />
            LIVE
          </span>
        </div>
      </header>

      {/* Score */}
      <div className="mx-auto w-full max-w-lg border-b border-border px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="text-center">
            <p className="text-lg font-bold">{match.team1Short}</p>
            <p className="text-sm font-semibold text-primary">{match.score1}</p>
          </div>
          <p className="font-display text-sm text-muted-foreground">VS</p>
          <div className="text-center">
            <p className="text-lg font-bold">{match.team2Short}</p>
            <p className="text-sm font-semibold text-primary">{match.score2}</p>
          </div>
        </div>
      </div>

      {/* Pool Players */}
      {pool && (
        <div className="mx-auto w-full max-w-lg border-b border-border px-4 py-3">
          <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Your Pool: {pool.name}</p>
          <div className="flex gap-3">
            {pool.players.map(player => (
              <div key={player.id} className="flex items-center gap-2 rounded-md bg-surface px-3 py-1.5">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-secondary">
                  <User className="h-3 w-3 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-[11px] font-semibold">{player.name}</p>
                  <p className="text-[9px] text-muted-foreground">{player.team}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Live Stats */}
      <div className="mx-auto w-full max-w-lg flex-1 px-4 py-6">
        <div className="grid grid-cols-3 gap-3 mb-8">
          <div className="rounded-lg bg-surface p-3 text-center">
            <TrendingUp className="mx-auto mb-1 h-4 w-4 text-primary" />
            <p className="text-xs text-muted-foreground">Multiplier</p>
            <p className={`text-lg font-bold animate-count ${multiplier >= (pool?.multiplier || 2.5) ? 'text-primary' : 'text-live'}`}>
              {multiplier}x
            </p>
          </div>
          <div className="rounded-lg bg-surface p-3 text-center">
            <Clock className="mx-auto mb-1 h-4 w-4 text-muted-foreground" />
            <p className="text-xs text-muted-foreground">Time In</p>
            <p className="text-lg font-bold">{Math.floor(seconds / 60)}:{(seconds % 60).toString().padStart(2, '0')}</p>
          </div>
          <div className="rounded-lg bg-surface p-3 text-center">
            <Zap className="mx-auto mb-1 h-4 w-4 text-primary" />
            <p className="text-xs text-muted-foreground">Your Bet</p>
            <p className="text-lg font-bold">₹{betAmountParam}</p>
          </div>
        </div>

        {/* Estimated Winnings */}
        <div className="mb-4 rounded-xl border border-primary/30 bg-surface p-6 text-center glow-gold">
          <p className="text-sm text-muted-foreground mb-1">
            {hasExited ? 'Secured Winnings' : 'Estimated Winnings'}
          </p>
          <p className="font-display text-4xl font-bold text-gold-gradient animate-count">
            ₹{hasExited ? exitAmount : estimatedWinning}
          </p>
          <p className={`mt-1 text-sm font-bold ${isProfit ? 'text-primary' : 'text-live'}`}>
            {isProfit ? '+' : ''}₹{profit} {isProfit ? 'profit' : 'loss'}
          </p>
          {!hasExited && (
            <p className="mt-2 text-xs text-muted-foreground">
              Winnings change based on match situation
            </p>
          )}
        </div>

        {/* Exit Button */}
        {!hasExited ? (
          <div className="text-center">
            <button
              onClick={handleExit}
              className="pulse-exit mx-auto flex h-28 w-28 items-center justify-center rounded-full bg-live text-center font-display text-lg font-black text-accent-foreground transition-transform active:scale-95"
            >
              EXIT<br/>NOW
            </button>
            <p className="mt-4 text-xs text-muted-foreground">
              Tap EXIT NOW to secure ₹{estimatedWinning}
            </p>
          </div>
        ) : (
          <div className="text-center space-y-4">
            <div className="inline-flex items-center gap-2 rounded-full bg-success/20 px-6 py-3 text-success font-bold">
              ✓ Exited Successfully
            </div>
            <p className="text-sm text-muted-foreground">
              ₹{exitAmount} has been added to your wallet
            </p>
            <button
              onClick={() => navigate('/')}
              className="mt-4 rounded-lg bg-secondary px-6 py-2 text-sm font-semibold text-secondary-foreground"
            >
              Back to Home
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default LiveMatch;
