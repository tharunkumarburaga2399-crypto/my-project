import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Eye, EyeOff } from 'lucide-react';

const Login = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/');
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6">
      <div className="w-full max-w-sm space-y-8">
        <div className="text-center">
          <h1 className="font-display text-3xl font-bold text-gold-gradient">EXIT 11</h1>
          <p className="mt-2 text-sm text-muted-foreground">Predict. Play. Exit to Win.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Email or Phone</label>
            <Input placeholder="Enter email or phone" className="bg-surface border-border" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Password</label>
            <div className="relative">
              <Input type={showPassword ? 'text' : 'password'} placeholder="Enter password" className="bg-surface border-border pr-10" />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div className="text-right">
            <button type="button" onClick={() => navigate('/forgot-password')} className="text-xs text-primary hover:underline">
              Forgot Password?
            </button>
          </div>

          <Button type="submit" className="w-full bg-gold-gradient text-primary-foreground font-bold hover:opacity-90">
            Login
          </Button>
        </form>

        <p className="text-center text-sm text-muted-foreground">
          Don't have an account?{' '}
          <button onClick={() => navigate('/register')} className="text-primary font-medium hover:underline">
            Register
          </button>
        </p>
      </div>
    </div>
  );
};

export default Login;
