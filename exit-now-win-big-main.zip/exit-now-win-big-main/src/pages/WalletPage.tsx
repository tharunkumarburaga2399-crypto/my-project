import { transactions } from '@/lib/mockData';
import { Plus, ArrowDownLeft, ArrowUpRight, Trophy, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';

const iconMap = {
  deposit: <ArrowDownLeft className="h-4 w-4 text-success" />,
  withdrawal: <ArrowUpRight className="h-4 w-4 text-live" />,
  pool_entry: <CreditCard className="h-4 w-4 text-muted-foreground" />,
  winning: <Trophy className="h-4 w-4 text-primary" />,
};

const WalletPage = () => {
  return (
    <div className="min-h-screen pb-20">
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-xl">
        <div className="mx-auto max-w-lg px-4 py-3">
          <h1 className="text-lg font-bold">Wallet</h1>
        </div>
      </header>

      <div className="mx-auto max-w-lg px-4 py-4 space-y-6">
        {/* Balance Card */}
        <div className="rounded-xl bg-gold-gradient p-6 glow-gold">
          <p className="text-xs font-medium text-primary-foreground/70">Total Balance</p>
          <p className="text-3xl font-bold text-primary-foreground">₹1,750.00</p>
          <div className="mt-4 flex gap-3">
            <Button size="sm" className="flex-1 bg-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/30 backdrop-blur-sm">
              <Plus className="mr-1 h-4 w-4" /> Add Money
            </Button>
            <Button size="sm" className="flex-1 bg-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/30 backdrop-blur-sm">
              <ArrowUpRight className="mr-1 h-4 w-4" /> Withdraw
            </Button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-lg bg-surface p-3 text-center">
            <p className="text-xs text-muted-foreground">Deposited</p>
            <p className="text-sm font-bold text-foreground">₹2,500</p>
          </div>
          <div className="rounded-lg bg-surface p-3 text-center">
            <p className="text-xs text-muted-foreground">Won</p>
            <p className="text-sm font-bold text-success">₹1,450</p>
          </div>
          <div className="rounded-lg bg-surface p-3 text-center">
            <p className="text-xs text-muted-foreground">Withdrawn</p>
            <p className="text-sm font-bold text-foreground">₹200</p>
          </div>
        </div>

        {/* Transactions */}
        <section>
          <h3 className="mb-3 text-sm font-bold uppercase tracking-wider text-muted-foreground">Transactions</h3>
          <div className="space-y-2">
            {transactions.map(tx => (
              <div key={tx.id} className="flex items-center gap-3 rounded-lg bg-card p-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-surface">
                  {iconMap[tx.type]}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{tx.description}</p>
                  <p className="text-xs text-muted-foreground">{tx.date}</p>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-bold ${tx.amount > 0 ? 'text-success' : 'text-foreground'}`}>
                    {tx.amount > 0 ? '+' : ''}₹{Math.abs(tx.amount)}
                  </p>
                  {tx.status === 'pending' && (
                    <span className="text-[10px] text-primary">Pending</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default WalletPage;
