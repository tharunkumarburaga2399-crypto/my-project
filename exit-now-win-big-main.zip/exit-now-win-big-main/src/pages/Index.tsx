import { matches } from '@/lib/mockData';
import MatchCard from '@/components/MatchCard';
import { Bell, Search } from 'lucide-react';

const Index = () => {
  const liveMatches = matches.filter(m => m.status === 'live');
  const upcomingMatches = matches.filter(m => m.status === 'upcoming');
  const completedMatches = matches.filter(m => m.status === 'completed');

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-lg items-center justify-between px-4 py-3">
          <h1 className="font-display text-xl font-bold text-gold-gradient">EXIT 11</h1>
          <div className="flex items-center gap-3">
            <button className="rounded-full p-2 text-muted-foreground hover:text-foreground transition-colors">
              <Search className="h-5 w-5" />
            </button>
            <button className="relative rounded-full p-2 text-muted-foreground hover:text-foreground transition-colors">
              <Bell className="h-5 w-5" />
              <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-live" />
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-lg px-4 py-4 space-y-6">
        {/* Wallet Banner */}
        <div className="rounded-lg bg-gold-gradient p-4 glow-gold">
          <p className="text-xs font-medium text-primary-foreground/70">Wallet Balance</p>
          <p className="text-2xl font-bold text-primary-foreground">₹1,750.00</p>
          <p className="mt-1 text-xs text-primary-foreground/60">+₹250 won today</p>
        </div>

        {/* Live Matches */}
        {liveMatches.length > 0 && (
          <section>
            <div className="mb-3 flex items-center gap-2">
              <span className="h-2 w-2 animate-pulse rounded-full bg-live" />
              <h2 className="text-sm font-bold uppercase tracking-wider text-live">Live Matches</h2>
            </div>
            <div className="space-y-3">
              {liveMatches.map(match => (
                <MatchCard key={match.id} match={match} />
              ))}
            </div>
          </section>
        )}

        {/* Upcoming */}
        {upcomingMatches.length > 0 && (
          <section>
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-muted-foreground">Upcoming</h2>
            <div className="space-y-3">
              {upcomingMatches.map(match => (
                <MatchCard key={match.id} match={match} />
              ))}
            </div>
          </section>
        )}

        {/* Completed */}
        {completedMatches.length > 0 && (
          <section>
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-muted-foreground">Completed</h2>
            <div className="space-y-3">
              {completedMatches.map(match => (
                <MatchCard key={match.id} match={match} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

export default Index;
