import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { matches, pools } from '@/lib/mockData';
import { ArrowLeft, Users, Star, TrendingUp, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

const roleBadge: Record<string, string> = {
  batsman: '🏏',
  bowler: '🎯',
  'all-rounder': '⚡',
  keeper: '🧤',
};

const MatchDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const match = matches.find(m => m.id === id);
  const matchPools = pools.filter(p => p.matchId === id);
  const [selectedPool, setSelectedPool] = useState<string | null>(null);
  const [betAmount, setBetAmount] = useState('');

  if (!match) return <div className="p-4 text-center text-muted-foreground">Match not found</div>;

  const handleJoinPool = () => {
    const amount = parseInt(betAmount);
    if (!selectedPool) {
      toast.error('Please select a pool');
      return;
    }
    if (!amount || amount < 10) {
      toast.error('Minimum bet is ₹10');
      return;
    }
    if (amount > 10000) {
      toast.error('Maximum bet is ₹10,000');
      return;
    }
    const pool = matchPools.find(p => p.id === selectedPool);
    if (!pool) return;

    // Navigate to live match with pool & bet info
    navigate(`/live/${match.id}?pool=${selectedPool}&bet=${amount}`);
    toast.success(`Joined "${pool.name}" with ₹${amount}`);
  };

  const quickAmounts = [50, 100, 500, 1000];

  return (
    <div className="min-h-screen pb-20">
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-lg items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex-1">
            <p className="text-sm font-semibold">{match.team1Short} vs {match.team2Short}</p>
            <p className="text-xs text-muted-foreground">{match.time}</p>
          </div>
          {match.status === 'live' && (
            <span className="flex items-center gap-1 rounded-full bg-live/20 px-2 py-0.5 text-xs font-bold text-live">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-live" />
              LIVE
            </span>
          )}
        </div>
      </header>

      {/* Score Card */}
      <div className="mx-auto max-w-lg border-b border-border px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="text-center">
            <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-secondary text-sm font-bold">{match.team1Short}</div>
            <p className="text-xs text-muted-foreground">{match.team1}</p>
            {match.score1 && <p className="mt-1 text-lg font-bold text-primary">{match.score1}</p>}
          </div>
          <p className="font-display text-xl font-bold text-muted-foreground">VS</p>
          <div className="text-center">
            <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-secondary text-sm font-bold">{match.team2Short}</div>
            <p className="text-xs text-muted-foreground">{match.team2}</p>
            {match.score2 && <p className="mt-1 text-lg font-bold text-primary">{match.score2}</p>}
          </div>
        </div>
      </div>

      {/* Player Pools */}
      <div className="mx-auto max-w-lg px-4 py-4">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-muted-foreground">
          <Star className="h-4 w-4 text-primary" /> Choose Your Pool
        </h3>
        <div className="space-y-3">
          {matchPools.map(pool => {
            const isSelected = selectedPool === pool.id;
            return (
              <button
                key={pool.id}
                onClick={() => setSelectedPool(pool.id)}
                className={`w-full rounded-lg border p-4 text-left transition-all ${
                  isSelected
                    ? 'border-primary bg-primary/10 ring-1 ring-primary'
                    : 'border-border bg-card hover:border-primary/30'
                }`}
              >
                <div className="mb-3 flex items-center justify-between">
                  <h4 className="text-sm font-bold">{pool.name}</h4>
                  <div className="flex items-center gap-1 rounded-full bg-primary/20 px-2 py-0.5">
                    <TrendingUp className="h-3 w-3 text-primary" />
                    <span className="text-xs font-bold text-primary">{pool.multiplier}x</span>
                  </div>
                </div>

                {/* Players */}
                <div className="mb-3 space-y-2">
                  {pool.players.map(player => (
                    <div key={player.id} className="flex items-center gap-2">
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary">
                        <User className="h-3.5 w-3.5 text-muted-foreground" />
                      </div>
                      <div className="flex-1">
                        <p className="text-xs font-semibold">{player.name}</p>
                        <p className="text-[10px] text-muted-foreground">{player.team} • {player.role}</p>
                      </div>
                      <span className="text-sm">{roleBadge[player.role]}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    {pool.participantCount} joined
                  </div>
                  <span>Pool: ₹{(pool.totalBets / 1000).toFixed(0)}K</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Bet Amount */}
        {selectedPool && (
          <div className="mt-6 rounded-lg border border-border bg-card p-4">
            <h4 className="mb-3 text-sm font-bold">Place Your Bet</h4>
            <Input
              type="number"
              placeholder="Enter bet amount (₹10 - ₹10,000)"
              value={betAmount}
              onChange={(e) => setBetAmount(e.target.value)}
              className="mb-3 text-center text-lg font-bold"
              min={10}
              max={10000}
            />
            <div className="mb-4 flex gap-2">
              {quickAmounts.map(amt => (
                <button
                  key={amt}
                  onClick={() => setBetAmount(String(amt))}
                  className={`flex-1 rounded-md py-2 text-xs font-bold transition-colors ${
                    betAmount === String(amt)
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>

            {betAmount && parseInt(betAmount) >= 10 && (
              <div className="mb-4 rounded-md bg-primary/10 p-3 text-center">
                <p className="text-xs text-muted-foreground">Potential Winning</p>
                <p className="text-xl font-bold text-primary">
                  ₹{(parseInt(betAmount) * (matchPools.find(p => p.id === selectedPool)?.multiplier || 1)).toFixed(0)}
                </p>
                <p className="text-[10px] text-muted-foreground">at current {matchPools.find(p => p.id === selectedPool)?.multiplier}x multiplier</p>
              </div>
            )}

            <Button
              onClick={handleJoinPool}
              className="w-full bg-gold-gradient text-primary-foreground font-bold hover:opacity-90"
              size="lg"
            >
              JOIN POOL — ₹{betAmount || '0'}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default MatchDetail;
