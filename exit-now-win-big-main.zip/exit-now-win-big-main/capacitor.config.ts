import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.exit11',
  appName: 'Exit 11',
  webDir: 'dist',
  server: {
    url: 'https://0efd5a56-ff12-43eb-a4a8-c269858c043c.lovableproject.com?forceHideBadge=true',
    cleartext: true
  }
};

export default config;
